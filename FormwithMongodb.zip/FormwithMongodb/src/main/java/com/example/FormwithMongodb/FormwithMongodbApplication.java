package com.example.FormwithMongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormwithMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormwithMongodbApplication.class, args);
	}

}
