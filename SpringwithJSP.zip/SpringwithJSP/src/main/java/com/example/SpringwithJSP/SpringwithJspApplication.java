package com.example.SpringwithJSP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwithJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwithJspApplication.class, args);
	}

}
