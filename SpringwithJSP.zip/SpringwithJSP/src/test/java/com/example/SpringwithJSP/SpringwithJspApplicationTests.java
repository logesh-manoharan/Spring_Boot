package com.example.SpringwithJSP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwithJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
