package com.example.Springwithmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwithmongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwithmongodbApplication.class, args);
	}

}
