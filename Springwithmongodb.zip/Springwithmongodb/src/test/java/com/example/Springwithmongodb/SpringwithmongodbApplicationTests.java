package com.example.Springwithmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwithmongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
