package com.example.firstspringproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstspringprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstspringprojectApplication.class, args);
	}

}
