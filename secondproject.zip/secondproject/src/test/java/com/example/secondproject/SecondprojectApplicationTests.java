package com.example.secondproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
